// Copyright Epic Games, Inc. All Rights Reserved.

#include "Project_PSG_425.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Project_PSG_425, "Project_PSG_425" );
