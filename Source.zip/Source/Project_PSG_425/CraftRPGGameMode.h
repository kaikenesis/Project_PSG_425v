#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "CraftRPGGameMode.generated.h"

UCLASS()
class PROJECT_PSG_425_API ACraftRPGGameMode : public AGameModeBase
{
	GENERATED_BODY()
	
public:
	ACraftRPGGameMode();
};
