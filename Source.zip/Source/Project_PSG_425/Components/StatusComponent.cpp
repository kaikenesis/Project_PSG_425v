#include "StatusComponent.h"
#include "Global.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Particles/ParticleSystemComponent.h"
#include "Action/BuffParticle.h"

UStatusComponent::UStatusComponent()
{

}

void UStatusComponent::BeginPlay()
{
	Super::BeginPlay();

	CurrentHealth = MaxHealth;
}

void UStatusComponent::SetMove()
{
	bCanMove = true;
}

void UStatusComponent::SetStop()
{
	bCanMove = false;
}

void UStatusComponent::ChangeMoveSpeed(EWalkSpeedType InType)
{
	CheckNull(GetOwner());

	UCharacterMovementComponent* movementComp = CHelpers::GetComponent<UCharacterMovementComponent>(GetOwner());
	CheckNull(movementComp);

	movementComp->MaxWalkSpeed = WalkSpeed[(int32)InType];
}

void UStatusComponent::IncreaseHealth(float InAmount)
{
	CurrentHealth += InAmount;
	CurrentHealth = FMath::Clamp(CurrentHealth, 0.f, MaxHealth);
}

void UStatusComponent::DecreaseHealth(float InAmount)
{
	CurrentHealth -= InAmount;
	CurrentHealth = FMath::Clamp(CurrentHealth, 0.f, MaxHealth);
}

void UStatusComponent::SetBurn(float InTickTime, int32 InTickCount, float TickDamage, bool IsLoop)
{
	if (BurnImmune == true)
		return;

	SetBurnCount(InTickCount);
	SetBurnTickDamage(TickDamage);
	UKismetSystemLibrary::K2_SetTimer(this, "Burn", InTickTime, IsLoop);
}

void UStatusComponent::Burn()
{
	if (BurnCount <= 0)
	{
		UKismetSystemLibrary::K2_ClearTimer(this, "Burn");

	}
		

	DecreaseHealth(BurnTickDamage);
	BurnCount--;
}

void UStatusComponent::PlayEffect(UParticleSystem* InParticle, FTransform InTransform)
{
	//Play Particle
	if (!!InParticle)
	{
		FTransform transform;
		ABuffParticle* particle = GetWorld()->SpawnActorDeferred<ABuffParticle>(ParticleClass, transform, GetOwner());
		particle->AttachToComponent
		(
			Cast<ACharacter>(GetOwner())->GetMesh(),
			FAttachmentTransformRules::FAttachmentTransformRules(EAttachmentRule::KeepRelative, EAttachmentRule::KeepWorld, EAttachmentRule::KeepRelative, true)
		);
		particle->Get()->SetTemplate(InParticle);
		particle->FinishSpawning(transform);
	}
}
